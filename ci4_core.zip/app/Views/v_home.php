<div class="row">
    <div class="col-sm-15 ">
        <div class="text-center">
            <h1><b>Welcome To</b></h1>
            <h3><b>Little SIAK</b></h3>
            <img class="pad" src="<?= base_url('img/university.png') ?>" margin-left = "25%" width ="40%"alt="Photo">
        </div>
    </div>

</div>